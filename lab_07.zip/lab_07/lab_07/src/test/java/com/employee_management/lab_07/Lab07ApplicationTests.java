package com.employee_management.lab_07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
