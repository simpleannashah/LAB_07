package com.employee_management.lab_07.controller;

import com.employee_management.lab_07.entity.Employee;
import com.employee_management.lab_07.service.EmployeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    @PostMapping("/add")
    public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {
        employeeService.saveEmployee(employee);
        return ResponseEntity.ok("Employee added successfully!");
    }

    // Get employees earning more than a specific salary
    @GetMapping("/salary/{amount}")
    public List<Employee> getEmployeesWithHighSalary(@PathVariable double amount) {
        return employeeService.getEmployeesWithSalaryGreaterThan(amount);
    }

    // Update employee salary by ID
    @PutMapping("/{id}/salary")
    public ResponseEntity<String> updateSalary(@PathVariable Long id, @RequestParam double newSalary) {
        boolean updated = employeeService.updateEmployeeSalary(id, newSalary);
        return updated ? ResponseEntity.ok("Salary updated successfully") :
                ResponseEntity.badRequest().body("Employee not found");
    }

    // Delete employee by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Long id) {
        boolean deleted = employeeService.deleteEmployeeById(id);
        return deleted ? ResponseEntity.ok("Employee deleted successfully") :
                ResponseEntity.badRequest().body("Employee not found");
    }

    // Search employees by name (case-insensitive)
    @GetMapping("/search")
    public List<Employee> searchEmployees(@RequestParam String name) {
        return employeeService.searchEmployeesByName(name);
    }
}
