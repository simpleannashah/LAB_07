package com.employee_management.lab_07.service;

import com.employee_management.lab_07.entity.Employee;
import com.employee_management.lab_07.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<Employee> getEmployeesWithSalaryGreaterThan(double amount) {
        return employeeRepository.findBySalaryGreaterThan(amount);
    }

    public boolean updateEmployeeSalary(Long id, double newSalary) {
        int updated = employeeRepository.updateEmployeeSalary(id, newSalary);
        return updated > 0;
    }

    public boolean deleteEmployeeById(Long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        if (employee.isPresent()) {
            employeeRepository.deleteEmployeeById(id);
            return true;
        }
        return false;
    }

    public List<Employee> searchEmployeesByName(String name) {
        return employeeRepository.searchEmployeesByName(name);
    }
    public void saveEmployee(Employee employee) {
        employeeRepository.save(employee);
    }

}
