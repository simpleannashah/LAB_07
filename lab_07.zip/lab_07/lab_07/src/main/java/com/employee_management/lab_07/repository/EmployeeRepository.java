package com.employee_management.lab_07.repository;

import com.employee_management.lab_07.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Retrieve employees with salary greater than given amount
    @Query("SELECT e FROM Employee e WHERE e.salary > :amount")
    List<Employee> findBySalaryGreaterThan(double amount);

    // Update salary of an employee by ID
    @Modifying
    @Transactional
    @Query("UPDATE Employee e SET e.salary = :newSalary WHERE e.id = :id")
    int updateEmployeeSalary(Long id, double newSalary);

    // Delete an employee by ID
    @Modifying
    @Transactional
    @Query("DELETE FROM Employee e WHERE e.id = :id")
    void deleteEmployeeById(Long id);

    // Search employees by name (case-insensitive)
    @Query("SELECT e FROM Employee e WHERE LOWER(e.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Employee> searchEmployeesByName(String name);
}
